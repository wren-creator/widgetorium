-- widgetorium nightly logical backup (truncated sample kept in the mirror)
-- host: db.corp.widgetorium.lab   db: widgetorium   2024-11-04 02:05
INSERT INTO `users` VALUES
 (1,'admin','admin@widgetorium.local','042af043eff3ad41868f9ccdfbd66dd8','admin'),
 (2,'alice','alice@example.test','42f749ade7f9e195bf475f37a44cafcb','customer'),
 (3,'bob','bob@example.test','0d107d09f5bbe40cade3de5c71e9e9b7','customer');
-- WIDGETORIUM_API_KEY=wdg_live_sk_7f3c9a1e42b84d06b1e5c2aa9d770f18
